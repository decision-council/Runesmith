"""Repair organ, generation 0: the Runesmith v1 repair policy.

This organ is a faithful port of Runesmith v1 — the generic navigate → edit →
public-feedback loop that served as the SR3/SR4 comparator — so that the first
Runesmith Core generation starts from the measured v1 policy rather than from a
policy tuned in advance. It is deliberately *mutable*: the Kaizen engine may
rewrite this file, and a rewritten copy becomes a new generation only after
qualification.

Contract (fixed by the kernel, not by this file):

* ``run(view, cockpit) -> dict`` is called once per repair opportunity.
* ``view`` holds ``issue``, ``failing_tests``, ``src_files`` (path -> text),
  ``src_sizes`` (path -> bytes on disk) and ``caps``; nothing else about the
  object is visible.
* ``cockpit.ask(packet, schema, purpose)`` makes one model call (charged even
  when the answer is unusable); ``cockpit.run_signal(files, trace)`` runs the
  object's public tests with ``files`` overriding the originals;
  ``cockpit.budget()`` reports what remains; ``cockpit.log(stage, **data)``
  records a telemetry mark.
* The return value names a ``status`` and the ``final_files`` to be judged.

Standard library only; the organ runs confined and cannot import the kernel.
"""

import ast
import copy
import json
import re

ORGAN = "repair"
ORGAN_VERSION = "repair-g0 (Runesmith v1 policy port)"

STRING = {"type": "string"}
NAV_SCHEMA = {"type": "object", "properties": {"reads": {"type": "array", "items": {
    "type": "object", "properties": {"path": STRING, "symbols": {"type": "array", "items": STRING}},
    "required": ["path", "symbols"], "additionalProperties": False}}},
    "required": ["reads"], "additionalProperties": False}
EDIT_SCHEMA = {"type": "object", "properties": {"edits": {"type": "array", "items": {
    "type": "object", "properties": {"path": STRING, "old_text": STRING, "new_text": STRING},
    "required": ["path", "old_text", "new_text"], "additionalProperties": False}}},
    "required": ["edits"], "additionalProperties": False}
MAX_MODEL_CALLS = 5
MAX_INDEXED_FILE_BYTES = 120_000


# ------------------------------------------------------------------ packets --

def canonical(payload):
    return json.dumps(payload, sort_keys=True, ensure_ascii=False)


def canonical_bytes(payload):
    return len(canonical(payload).encode("utf-8"))


def fit_rows(payload, key, cap):
    fitted = copy.deepcopy(payload)
    while canonical_bytes(fitted) > cap and fitted[key]:
        fitted[key].pop()
    if canonical_bytes(fitted) > cap:
        raise ValueError("fixed packet fields exceed the byte cap")
    return fitted


def fit_segments(payload, cap):
    fitted = copy.deepcopy(payload)
    packets = fitted["source_packets"]
    while canonical_bytes(fitted) > cap and packets:
        last = packets[-1]
        if last.get("source_segments"):
            last["source_segments"].pop()
        else:
            packets.pop()
    if canonical_bytes(fitted) > cap or not packets:
        raise ValueError("edit packet cannot fit the byte cap")
    return fitted


def extract_test_hints(issue):
    """Extract keywords from failing test names that may indicate relevant source files."""
    hints = set()
    for match in re.finditer(r'test_([a-z_]+)(?:\.py|::)', issue.lower()):
        parts = match.group(1).split('_')
        hints.update(p for p in parts if len(p) > 2)
    return hints


def score_path_hints(path, hints):
    """Count how many hint keywords appear in a path."""
    path_lower = path.lower()
    return sum(1 for h in hints if h in path_lower)


def extract_error_paths(issue):
    """Extract Python module paths from error messages that map to source files."""
    paths = set()
    # Match dotted module paths like 'communityhat.adapters.github_app'
    for match in re.finditer(r'\b((?:communityhat|enrichhat)(?:\.[a-z_][a-z0-9_]*)+)', issue.lower()):
        parts = match.group(1).split('.')
        for i in range(2, len(parts) + 1):
            path = 'src/' + '/'.join(parts[:i]) + '.py'
            paths.add(path)
    return paths


def extract_error_symbols(issue):
    """Extract PascalCase class names from error messages."""
    symbols = set()
    # Match PascalCase names like QueueDepth, GitHubAppError, ConsumerStats
    for match in re.finditer(r'\b([A-Z][a-z0-9]+(?:[A-Z][a-z0-9]+)+)\b', issue):
        symbols.add(match.group(1))
    return symbols


def navigation_packet(issue, index, test_hints=None, error_paths=None):
    packet = {
        "task": "Inspect this parent source index; choose at most four files and up to three exact symbols per file to read before editing.",
        "issue": issue,
        "source_index": index,
        "output": {"reads": [{"path": "src/example.py", "symbols": ["function_name"]}]},
        "constraints": ["Choose only listed parent paths and symbols.",
                        "No tests, Git history or solution is available."],
    }
    if test_hints:
        packet["test_keyword_hints"] = sorted(test_hints)[:10]
        packet["constraints"].append("Prioritize files whose paths contain the test_keyword_hints words.")
    if error_paths:
        packet["error_module_paths"] = sorted(error_paths)[:8]
        packet["constraints"].append("Files in error_module_paths match the module path from the error; read them first.")
    return packet


def edit_packet(issue, snippets):
    return {
        "task": "Implement the issue using exact old_text/new_text source edits; no tests are visible.",
        "issue": issue, "source_packets": snippets,
        "constraints": ["Edit only the source paths shown in source_packets.",
                        "Each old_text must occur exactly once in the original full file.",
                        "Copy old_text only from source_segments[].source; metadata is not code.",
                        "Review callers and downstream behavior visible in these snippets.",
                        "Return an empty edits list if the visible source cannot justify a change."],
        "output": {"edits": [{"path": "src/example.py", "old_text": "exact original text",
                              "new_text": "replacement text"}]},
    }


# ---------------------------------------------------------------- selector --

def _path_key(path):
    return tuple(part.lower() for part in path.split("/"))


def source_index(files, sizes):
    """One row per parseable src/*.py file: its top-level symbols."""
    rows = []
    for path in sorted((p for p in files if p.startswith("src/") and p.endswith(".py")), key=_path_key):
        if sizes.get(path, len(files[path].encode("utf-8"))) > MAX_INDEXED_FILE_BYTES:
            continue
        try:
            tree = ast.parse(files[path])
        except (SyntaxError, ValueError):
            continue
        symbols = [node.name for node in tree.body
                   if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
        rows.append({"path": path, "symbols": symbols, "read_only": False})
    return rows


def requested_excerpt(path, text, symbols, max_chars=6000):
    lines = text.splitlines(keepends=True)
    tree = ast.parse(text)
    header = ""
    for line in lines[:25]:
        if len(header) + len(line) > min(900, max_chars):
            break
        header += line
    output = [{"kind": "module_header", "start_line": 1, "source": header}]
    used = len(header)
    selected_nodes = []
    for name in symbols:
        found = [node for node in ast.walk(tree)
                 if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                 and node.name == name and hasattr(node, "end_lineno")]
        if not found:
            output.append({"kind": "missing_symbol", "name": name})
            continue
        node = sorted(found, key=lambda value: (value.lineno, value.end_lineno))[0]
        selected_nodes.append(node)
        body_lines = lines[node.lineno - 1:node.end_lineno]
        body = "".join(body_lines)
        remaining = max_chars - used
        if remaining < 300:
            break
        if len(body) <= remaining:
            output.append({"kind": "symbol", "name": name, "start_line": node.lineno, "source": body})
            used += len(body)
            continue
        prefix_lines = []
        prefix_budget = remaining * 2 // 3
        for line in body_lines:
            if sum(map(len, prefix_lines)) + len(line) > prefix_budget:
                break
            prefix_lines.append(line)
        suffix_lines = []
        suffix_budget = remaining - sum(map(len, prefix_lines))
        for line in reversed(body_lines[len(prefix_lines):]):
            if sum(map(len, suffix_lines)) + len(line) > suffix_budget:
                break
            suffix_lines.append(line)
        if prefix_lines:
            output.append({"kind": "symbol_prefix", "name": name, "start_line": node.lineno,
                           "source": "".join(prefix_lines), "truncated": True})
            used += sum(map(len, prefix_lines))
        if suffix_lines:
            output.append({"kind": "symbol_suffix", "name": name,
                           "start_line": node.end_lineno - len(suffix_lines) + 1,
                           "source": "".join(reversed(suffix_lines)), "truncated": True})
            used += sum(map(len, suffix_lines))
    # Two bounded same-module dependency hops.
    if path.startswith("src/"):
        top_level = {node.name: node for node in tree.body
                     if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                     and hasattr(node, "end_lineno")}
        seen = set(symbols)
        frontier = selected_nodes
        for depth in range(1, 3):
            counts = {}
            for node in frontier:
                for child in ast.walk(node):
                    if isinstance(child, ast.Call) and isinstance(child.func, ast.Name):
                        name = child.func.id
                        if name in top_level and name not in seen:
                            counts[name] = counts.get(name, 0) + 1
            next_frontier = []
            for name in sorted(counts, key=lambda value: (-counts[value], value)):
                seen.add(name)
                node = top_level[name]
                body = "".join(lines[node.lineno - 1:node.end_lineno])
                if used + len(body) > max_chars:
                    continue
                output.append({"kind": "dependency", "depth": depth, "name": name,
                               "start_line": node.lineno, "source": body})
                used += len(body)
                next_frontier.append(node)
            frontier = next_frontier
    return output


def normalize_navigation(files, catalog, navigation):
    """Compile model-proposed reads into bounded exact source packets."""
    reads = navigation.get("reads", [])
    if not isinstance(reads, list) or not reads:
        raise ValueError("invalid navigation reads")
    snippets, allowed = [], set()
    for item in reads[:4]:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            continue
        path, symbols = item["path"], item.get("symbols", [])
        if path not in catalog:
            continue
        if not isinstance(symbols, list):
            symbols = []
        valid = [name for name in symbols if isinstance(name, str) and name in catalog[path]["symbols"]][:3]
        if not catalog[path]["read_only"]:
            allowed.add(path)
        snippets.append({"path": path, "read_only": catalog[path]["read_only"],
                         "source_segments": requested_excerpt(path, files[path], valid)})
    if not snippets or not allowed:
        raise ValueError("navigation yielded no editable source paths")
    return snippets, allowed


# -------------------------------------------------------------------- edits --

def apply_edits(current, edits, allowed):
    """All-or-nothing exact edits against the current file texts; returns changed texts."""
    if not isinstance(edits, list) or not 1 <= len(edits) <= 6:
        raise ValueError("invalid edit count")
    staged = {}
    for edit in edits:
        if not isinstance(edit, dict) or set(edit) != {"path", "old_text", "new_text"}:
            raise ValueError("invalid edit schema")
        path, old, new = edit["path"], edit["old_text"], edit["new_text"]
        if path not in allowed or not isinstance(old, str) or not isinstance(new, str) or not old or old == new:
            raise ValueError("edit outside delivered source or no-op")
        text = staged.get(path, current[path])
        if text.count(old) != 1:
            raise ValueError("old_text did not match exactly once in the current file")
        staged[path] = text.replace(old, new, 1)
    return staged


# ---------------------------------------------------------------------- run --

def run(view, cockpit):
    issue = view["issue"]
    files = view["src_files"]
    caps = view["caps"]
    state = {}                      # cumulative overrides: path -> current full text
    calls = 0
    # Run trace before navigation to identify which source files the failing tests execute
    trace_result = cockpit.run_signal(trace=True)
    executed_files = set(trace_result.get("executed_src_lines", {}).keys())
    cockpit.log("index")
    index = source_index(files, view.get("src_sizes", {}))
    # Extract keywords from test names to identify likely buggy files
    test_hints = extract_test_hints(issue)
    # Extract module paths from error messages (e.g., 'communityhat.adapters.github_app')
    error_paths = extract_error_paths(issue)
    # Extract class names from error messages (e.g., 'QueueDepth', 'GitHubAppError')
    error_symbols = extract_error_symbols(issue)
    # Sort by: error path match (desc), symbol match (desc), hint matches (desc), executed (desc), path (asc)
    def file_priority(row):
        error_match = 1 if row["path"] in error_paths else 0
        symbol_match = len(set(row.get("symbols", [])) & error_symbols)
        hint_score = score_path_hints(row["path"], test_hints)
        is_exec = 1 if row["path"] in executed_files else 0
        return (-error_match, -symbol_match, -hint_score, -is_exec, row["path"])
    index.sort(key=file_priority)
    nav_packet = fit_rows(navigation_packet(issue, index, test_hints, error_paths), "source_index", caps["nav_cap_bytes"])
    cockpit.log("navigate", indexed=len(index), delivered=len(nav_packet["source_index"]))
    navigation = cockpit.ask(nav_packet, NAV_SCHEMA, "navigate")
    calls += 1
    # Prepare deterministic fallback reads based on the indexed source files.
    fallback_reads = []
    for row in index[:4]:
        if row["symbols"]:
            fallback_reads.append({"path": row["path"], "symbols": row["symbols"][:3]})
    # If navigation failed or produced unusable data, use fallback.
    if not navigation.get("ok") or not isinstance(navigation.get("data", {}), dict) or not navigation["data"].get("reads"):
        navigation = {"ok": True, "data": {"reads": fallback_reads}}
    # Build catalog from the indexed source.
    catalog = {row["path"]: row for row in nav_packet["source_index"]}
    # Inject error_path files into reads (highest confidence signal from error messages)
    nav_reads = navigation["data"].get("reads", [])
    if isinstance(nav_reads, list):
        read_paths = {r.get("path") for r in nav_reads if isinstance(r, dict)}
        for path in sorted(error_paths):
            if path in catalog and path not in read_paths:
                nav_reads.insert(0, {"path": path, "symbols": catalog[path].get("symbols", [])[:3]})
        navigation["data"]["reads"] = nav_reads[:4]
    # Try to normalize navigation; on any error, fall back to deterministic reads.
    try:
        snippets, _ = normalize_navigation(files, catalog, navigation["data"])
    except Exception:
        snippets, _ = normalize_navigation(files, catalog, {"reads": fallback_reads})
    try:
        packet0 = fit_segments(edit_packet(issue, snippets), caps["edit_cap_bytes"])
    except ValueError as error:
        return {"status": "instrument_subject_failure", "final_files": state, "detail": str(error)[:300]}
    allowed = {item["path"] for item in packet0["source_packets"]}
    cockpit.log("edit_loop", reads=sorted(allowed))
    packet, feedback, last_edits, edited = packet0, None, None, set()
    while calls < MAX_MODEL_CALLS:
        if feedback is not None:
            packet = {"task": "Your previous edit did not fix the failing tests. Use the feedback and the current source to propose corrected exact old_text/new_text edits.",
                      "issue": issue, "source_packets": packet0["source_packets"],
                      "current_files": {p: state.get(p, files[p])[:12000] for p in sorted(edited)},
                      "previous_edits": last_edits, "feedback": feedback,
                      "constraints": packet0["constraints"], "output": packet0["output"]}
            try:
                packet = fit_rows(packet, "source_packets", caps["edit_cap_bytes"] + 16000)
            except ValueError as error:
                return {"status": "instrument_subject_failure", "final_files": state, "detail": str(error)[:300]}
        answer = cockpit.ask(packet, EDIT_SCHEMA, "edit" if feedback is None else f"retry{calls}")
        calls += 1
        if not answer["ok"]:
            feedback = {"kind": "output_failure", "detail": answer.get("error")}
            continue
        last_edits = answer["data"].get("edits")
        try:
            current = {p: state.get(p, files[p]) for p in allowed}
            changed = apply_edits(current, last_edits, allowed)
        except ValueError as error:
            feedback = {"kind": "edit_rejected", "detail": str(error)}
            continue
        state.update(changed)
        edited.update(changed)
        result = cockpit.run_signal(files=state)
        if result["passed"]:
            return {"status": "public_pass", "final_files": state}
        feedback = {"kind": "public_tests_failed", "signal_lines": result["signal_lines"]}
    return {"status": "budget_exhausted", "final_files": state}
